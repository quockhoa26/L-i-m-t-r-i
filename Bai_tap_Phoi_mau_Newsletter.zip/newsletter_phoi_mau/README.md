# Bài tập: Phối màu cho Newsletter

Dự án gồm 2 phiên bản newsletter responsive, xây dựng bằng HTML, CSS và Bootstrap 5.

## Cấu trúc thư mục

- `index.html`: Phiên bản 1 — Fresh & Optimistic
- `style1.css`: CSS và bảng màu phiên bản 1
- `newsletter_version2.html`: Phiên bản 2 — Warm Editorial
- `style2.css`: CSS và bảng màu phiên bản 2

## Hai bảng màu

### Phiên bản 1 — Fresh & Optimistic
- Navy: `#173B57`
- Teal: `#168C86`
- Coral: `#FF8066`
- Mint: `#D8F3E8`
- Cream: `#F7F8F2`

Cảm nhận: tươi mới, tích cực, thân thiện; xanh teal làm màu nhận diện, coral dùng làm điểm nhấn.

### Phiên bản 2 — Warm Editorial
- Plum: `#4B2545`
- Terracotta: `#9A493E`
- Gold: `#D89A35`
- Blush: `#F7E7DF`
- Ivory: `#FCF7F0`

Cảm nhận: ấm áp, sáng tạo và có tính biên tập; tông mận tạo chiều sâu, vàng làm điểm nhấn.

## Cách chạy
Mở `index.html` hoặc `newsletter_version2.html` bằng trình duyệt. Bootstrap và Google Fonts dùng CDN nên cần Internet để tải đầy đủ kiểu dáng và phông chữ; phần bố cục chính vẫn nằm trong mã nguồn.

## Cách đưa lên GitHub
1. Tạo repository mới trên GitHub.
2. Tải lên cả 5 file trong thư mục này (hoặc giải nén ZIP rồi tải các file lên).
3. Vào **Settings → Pages**.
4. Ở **Build and deployment**, chọn **Deploy from a branch**.
5. Chọn branch `main`, thư mục `/ (root)`, rồi nhấn **Save**.
6. Đợi GitHub Pages xuất bản trang. Trang chính thường là `https://TEN-GITHUB.github.io/TEN-REPOSITORY/`.
7. Phiên bản 2 ở đường dẫn `https://TEN-GITHUB.github.io/TEN-REPOSITORY/newsletter_version2.html`.

## Ghi chú về Adobe Color
Các bảng màu được chọn theo định hướng phối màu và ghi rõ mã HEX để phục vụ bài tập. Nếu giảng viên yêu cầu minh chứng thao tác trực tiếp trên Adobe Color, hãy mở https://color.adobe.com/, nhập các mã HEX trên vào bảng màu của bạn và chụp ảnh màn hình lưu cùng bài nộp.
