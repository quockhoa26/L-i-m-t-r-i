# Bài tập: Xây dựng Landing Page CodeGym Career

Landing page responsive lấy cảm hứng từ nội dung và mục tiêu của CodeGym Career, trình bày lại theo phong cách Material Design bằng Bootstrap 4 + Material Design for Bootstrap (MDBootstrap 4).

## File trong dự án
- `index.html` — cấu trúc trang HTML.
- `style.css` — màu sắc, bố cục responsive và tùy chỉnh giao diện.
- `script.js` — tương tác menu di động, nút lên đầu trang và form demo.

## Thành phần giao diện
- Navbar responsive.
- Hero section với nút CTA và minh họa code.
- Thẻ lợi ích (Cards).
- Lộ trình phát triển theo từng bước.
- Khối trích dẫn minh họa.
- Form liên hệ/tư vấn.
- Footer và nút quay lại đầu trang.

## Chạy thử
Mở `index.html` bằng trình duyệt. Các thư viện Bootstrap, MDBootstrap, Font Awesome và Google Fonts được tải qua CDN nên cần Internet.

## Lưu ý nội dung
Đây là sản phẩm bài tập/demo giao diện, không phải trang chính thức của CodeGym. Nội dung lộ trình và trích dẫn trong trang là nội dung minh họa được biên soạn cho bài tập; không khẳng định cam kết việc làm, số liệu thành tích hay lời chứng thực học viên. Biểu mẫu chỉ kiểm tra ở trình duyệt, không gửi hoặc lưu thông tin.

## Đưa lên GitHub Pages
1. Tạo repository GitHub mới, ví dụ `codegym-career-landing`.
2. Tải lên `index.html`, `style.css`, `script.js`, và `README.md`.
3. Chọn **Settings → Pages**.
4. Ở **Build and deployment**, chọn **Deploy from a branch**, branch `main`, thư mục `/ (root)`, rồi **Save**.
5. Sau khi triển khai xong, mở `https://TEN-GITHUB.github.io/codegym-career-landing/`.

Trang nội dung tham khảo theo yêu cầu bài tập: https://codegym.vn/codegym-career/
