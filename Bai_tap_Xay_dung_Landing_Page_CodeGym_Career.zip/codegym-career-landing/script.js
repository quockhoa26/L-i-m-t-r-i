// Tương tác nhỏ cho Landing Page CodeGym Career
(function () {
  'use strict';

  // Đóng menu di động sau khi người dùng chọn một mục.
  document.querySelectorAll('#mainNav .nav-link, #mainNav .btn').forEach(function (link) {
    link.addEventListener('click', function () {
      if (window.jQuery && window.innerWidth < 992) {
        window.jQuery('#mainNav').collapse('hide');
      }
    });
  });

  // Hiện nút quay lại đầu trang khi cuộn xuống.
  var backToTop = document.getElementById('backToTop');
  function updateBackToTop() {
    if (!backToTop) return;
    backToTop.style.display = window.scrollY > 450 ? 'grid' : 'none';
  }
  window.addEventListener('scroll', updateBackToTop, { passive: true });
  updateBackToTop();

  if (backToTop) {
    backToTop.addEventListener('click', function () {
      window.scrollTo({ top: 0, behavior: 'smooth' });
    });
  }

  // Form demo: kiểm tra dữ liệu ở trình duyệt, không gửi lên máy chủ.
  var form = document.getElementById('consultForm');
  var message = document.getElementById('formMessage');
  if (form && message) {
    form.addEventListener('submit', function (event) {
      event.preventDefault();
      if (!form.checkValidity()) {
        form.reportValidity();
        return;
      }
      var name = document.getElementById('fullName').value.trim();
      message.textContent = 'Cảm ơn ' + name + '! Đây là bản demo, thông tin chưa được gửi đi.';
      form.reset();
      form.querySelectorAll('label').forEach(function (label) {
        label.classList.remove('active');
      });
    });
  }
})();
